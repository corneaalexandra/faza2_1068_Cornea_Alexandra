var express = require("express")
var Sequelize = require("sequelize")
var nodeadmin = require("nodeadmin")
var cors = require("cors");

var sequelize = new Sequelize('vacante', 'root', '', {
    dialect:'mysql',
    host:'localhost'
})

sequelize.authenticate().then(function(){
    console.log('Success')
})

var Locations = sequelize.define('locations', {
    country: Sequelize.STRING,
    town: Sequelize.STRING,
    price: Sequelize.INTEGER
})

var Clients = sequelize.define('clients', {
    name: Sequelize.STRING,
    location_id: Sequelize.INTEGER,
    email: Sequelize.STRING
    
})

Clients.belongsTo(Locations, {foreignKey: 'location_id', targetKey: 'id'})





var app = express()

app.use('/nodeamin', nodeadmin(app))

//access static files
app.use(express.static('public'))
app.use('/admin', express.static('admin'))

app.use(express.json());       // to support JSON-encoded bodies
app.use(express.urlencoded()); // to support URL-encoded bodies
app.use(cors())

app.get('/locations', function(request, response) {
    Locations.findAll().then(function(locations){
        response.status(200).send(locations)
    })
        
})

// get one category by id
app.get('/locations/:id', function(request, response) {
    Locations.findOne({where: {id:request.params.id}}).then(function(location) {
        if(location) {
            response.status(200).send(location)
        } else {
            response.status(404).send()
        }
    })
})

//create a new category
app.post('/locations', function(request, response) {
    Locations.create(request.body).then(function(location) {
        response.status(201).send(location)
    })
})

app.put('/locations/:id', function(request, response) {
    Locations.findById(request.params.id).then(function(location) {
        if(location) {
            location.update(request.body).then(function(location){
                response.status(201).send(location)
            }).catch(function(error) {
                response.status(200).send(error)
            })
        } else {
            response.status(404).send('Not found')
        }
    })
})

app.delete('/locations/:id', function(request, response) {
    Locations.findById(request.params.id).then(function(location) {
        if(location) {
            location.destroy().then(function(){
                response.status(204).send()
            })
        } else {
            response.status(404).send('Not found')
        }
    })
})

app.get('/clients', function(request, response) {
    Clients.findAll(
        {
            include: [{
                model: Locations,
                where: { id: Sequelize.col('clients.location_id') }
            }]
        }
        
        ).then(
            function(clients) {
                response.status(200).send(clients)
            }
        )
})

app.get('/clients/:id', function(request, response) {
    Clients.findById(request.params.id).then(
            function(client) {
                response.status(200).send(client)
            }
        )
})

app.post('/clients', function(request, response) {
    Clients.create(request.body).then(function(client) {
        response.status(201).send(client)
    })
})

app.put('/clients/:id', function(request, response) {
    Clients().findById(request.params.id).then(function(client) {
        if(client) {
            client.update(request.body).then(function(client){
                response.status(201).send(client)
            }).catch(function(error) {
                response.status(200).send(error)
            })
        } else {
            response.status(404).send('Not found')
        }
    })
})

app.delete('/clients/:id', function(request, response) {
    Clients.findById(request.params.id).then(function(client) {
        if(client) {
            client.destroy().then(function(){
                response.status(204).send()
            })
        } else {
            response.status(404).send('Not found')
        }
    })
})


app.listen(8080)